This program was written and tested in MATLAB version R2017b.

The main program startAlgorithmCR.m should be executed from within the
folder ./code/nonconforming/.

Parameters for experiments can be choosen in a benchmark file in
./code/nonconforming/benchmarks/.
A blueprint for such a file is editable.m in said folder.

More information about the implementation can be found in
bachelorThesisMain.pdf.
