function y = bubble(x)
  y = sin(pi*x(:, 1)).*sin(pi*x(:, 2));
end
